/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package viewpages;

/**
 *
 * @author mones
 */
public class FrontEndPagesV3 {

    
    public static void main(String[] args) {
        // TODO code application logic here
        
        new CardScrollView().show();
        new DlgHistView().show();
        new DlgListView().show();
        new ProView().show();
        new RegisterView().show();
        new SetUpDlgView().show();
        new SettingsView().show();
        new SupView().show();
        new UListStdView().show();
        new UListTchView().show();
        new loginView().show();
        
    }
    
}
