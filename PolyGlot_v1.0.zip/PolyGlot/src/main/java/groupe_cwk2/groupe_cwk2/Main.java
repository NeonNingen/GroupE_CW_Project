/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package groupe_cwk2.groupe_cwk2;


/**
 *
 * @author Amit
 */
public class Main 
{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
       //to test that everything works, UserModel was used to test the methods
       UserModel user = new UserModel();
       
       //calling the methodss
       //user.insert();
       user.retrieveUserList();
       //user.delete();
       //user.update();
        
    }
    
}
